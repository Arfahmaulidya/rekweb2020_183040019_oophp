<?php 


// define('NAMA', 'Arfah Maulidya');
// echo NAMA;

// echo "<br>";

// const UMUR = 20;
// echo UMUR;


// Class Coba {
// 	const NAMA = 'Arfah';
// }

// echo Coba::NAMA;

// echo __FILE__; // menampilkan nomor baris ditulis


// function coba(){
// 	return __FUNCTION__;
// }

// echo coba();


class Coba{
	public $kelas = __CLASS__;
}

$obj = new Coba;
echo $obj->kelas;


 ?>